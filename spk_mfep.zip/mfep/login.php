<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>SKP MFEP</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style type="text/css">
<!--
.style1 {
	font-family: "Times New Roman", Times, serif;
	font-size: 18px;
}
-->
    </style>
</head>
  <body style="background: #ffffff url(images/back1.jpg) left bottom fixed;">
  
	<nav class="navbar navbar-inverse navbar-static-top">
	  <div class="container">
		<!-- Brand and toggle get grouped for better mobile display -->
		<div class="navbar-header">
		  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
			<span class="sr-only">Toggle navigation</span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
		  </button>
		  <a class="navbar-brand" ">SPK Pemilihan Mobil Bekas Berkualitas </a>
		</div>

		<!-- Collect the nav links, forms, and other content for toggling -->
		<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
		  <ul class="nav navbar-nav navbar-right">
			<li><a href=""> Metode Multifactor Evaluation Process (MFEP)</a></li>
		  </ul>
		</div><!-- /.navbar-collapse -->
	  </div><!-- /.container-fluid -->
	</nav>
    
     <div class="container">
		<div class="row"> 	

		  	<div style="margin-top: 10px;" class="panel panel-default"><div class="panel-body">
		  		<div class="text-center"><h4>CV. AZKA AUTO MUARA BUNGO</h4>
                <p>
                </p></div>

<table width="1100" height="405">
<tr>
<td width="814"  >
  <div align="justify" class="style1">	Showroom Azka Auto pertama kali berditi pada tahun 2016 oleh Haryjuliansyah Putra alias Hary, perusahaan ini bergerak dalam bidang jual beli mobil bekas , berlokasi di Jl. Lintas Sumatera arah bangko Km.03,Kelurahan Pasir Putih, Kecamatan Rimbo Tengah, Kabupaten Bungo, Jambi.
Pada awalnya sang pemilik adalah seorang makelar yang bertugas sebagai perantara dua pihak antara penjual dan pembeli mobil bekas, dengan usaha ini Hary mendapatkan keuntungan dari usahanya menjadi makelar, keuntungan tersebut dikumpulkan Hary untuk modal awal merintis usaha jual beli mobil bekas.
Awal perintisan beliau hanya dapat menjual beberapa mobil saja, dan belum memiliki showroom sebagai tempat transaksi jual beli, transaksi jual beli hanya dilakukan dari rumah kerumah atau lokasi dimana pembeli berada, pemasaran jual beli mobil bekas ini berawal dengan menawarkan mobil kepada teman, kerabat ,dan orang-orang terdekat.
 </div></td>
<td width="72"> </td>
<td width="198">	<div class="text-center"><h4>Login</h4></div>
		  		
                    <form action="log.php" method="POST" >	
                  
				  <div class="form-group">
				    <label for="InputUsername1">Username</label>
				    <input type="text" class="form-control" name="username"  id="InputUsername1" placeholder="Username">
				  </div>
				  <div class="form-group">
				    <label for="InputPassword1">Password</label>
				    <input type="password" class="form-control" name="password" id="InputPassword1" placeholder="Password">
				  </div>

				  <div align="center">
                   <button name="login"class="btn btn-primary">Log In</button> 
				  
				</form>
                
      
    </td>
        </tr>
    </table>        	  		
		  	</div></div>
		  	
		  </div>
		</div>
	</div>
         
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="js/jquery-1.11.3.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>