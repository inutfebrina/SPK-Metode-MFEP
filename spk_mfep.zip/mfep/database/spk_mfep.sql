-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 04, 2021 at 08:05 AM
-- Server version: 5.6.20
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `spk_mfep`
--

-- --------------------------------------------------------

--
-- Table structure for table `alternatif`
--

CREATE TABLE IF NOT EXISTS `alternatif` (
`id_alternatif` int(11) NOT NULL,
  `nama_alternatif` varchar(255) NOT NULL,
  `hasil_alternatif` double NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `alternatif`
--

INSERT INTO `alternatif` (`id_alternatif`, `nama_alternatif`, `hasil_alternatif`) VALUES
(12, 'Avanza', 11.6),
(13, 'Inova', 12.7),
(14, 'Pajero', 11.7),
(15, 'Ayla', 12.3),
(16, 'Fortuner', 11);

-- --------------------------------------------------------

--
-- Table structure for table `kriteria`
--

CREATE TABLE IF NOT EXISTS `kriteria` (
`id_kriteria` int(11) NOT NULL,
  `nama_kriteria` varchar(255) NOT NULL,
  `bobot_kriteria` double NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=22 ;

--
-- Dumping data for table `kriteria`
--

INSERT INTO `kriteria` (`id_kriteria`, `nama_kriteria`, `bobot_kriteria`) VALUES
(12, 'Kategori Kendaraan', 0.5),
(13, 'Transmisi', 0.2),
(14, 'Bahan Bakar', 0.2),
(15, 'Kapasitas Penumpang', 0.5),
(16, 'Warna Mobil', 0.5),
(17, 'Kapasitas Bagasi', 0.3),
(18, 'Kondisi Mesin', 0.3),
(19, 'Tahun Pembuatan', 0.4),
(20, 'Ukuran CC', 0.5),
(21, 'Harga Beli', 0.5);

-- --------------------------------------------------------

--
-- Table structure for table `nilai`
--

CREATE TABLE IF NOT EXISTS `nilai` (
`id_nilai` int(11) NOT NULL,
  `ket_nilai` varchar(255) NOT NULL,
  `jum_nilai` double NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `nilai`
--

INSERT INTO `nilai` (`id_nilai`, `ket_nilai`, `jum_nilai`) VALUES
(1, 'Lima', 5),
(2, 'Empat', 4),
(3, 'Tiga', 3),
(4, 'Dua', 2),
(5, 'Satu', 1);

-- --------------------------------------------------------

--
-- Table structure for table `pengguna`
--

CREATE TABLE IF NOT EXISTS `pengguna` (
`id_pengguna` int(11) NOT NULL,
  `nama_lengkap` varchar(255) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `level` varchar(10) DEFAULT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `pengguna`
--

INSERT INTO `pengguna` (`id_pengguna`, `nama_lengkap`, `username`, `password`, `level`) VALUES
(1, 'Admin', 'admin', '21232f297a57a5a743894a0e4a801fc3', ''),
(2, 'Pimpinan', 'pimpinan', '90973652b88fe07d05a4304f0a945de8', '1');

-- --------------------------------------------------------

--
-- Table structure for table `rangking`
--

CREATE TABLE IF NOT EXISTS `rangking` (
  `id_alternatif` int(11) NOT NULL,
  `id_kriteria` int(11) NOT NULL,
  `nilai_rangking` double NOT NULL,
  `nilai_normalisasi` double NOT NULL,
  `bobot_normalisasi` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rangking`
--

INSERT INTO `rangking` (`id_alternatif`, `id_kriteria`, `nilai_rangking`, `nilai_normalisasi`, `bobot_normalisasi`) VALUES
(12, 12, 2, 2, 1),
(12, 13, 2, 2, 0.4),
(12, 14, 1, 1, 0.2),
(12, 15, 5, 5, 2.5),
(12, 16, 4, 4, 2),
(12, 17, 2, 2, 0.6),
(12, 18, 2, 2, 0.6),
(12, 19, 2, 2, 0.8),
(12, 20, 3, 3, 1.5),
(12, 21, 4, 4, 2),
(13, 12, 5, 5, 2.5),
(13, 13, 2, 2, 0.4),
(13, 14, 2, 2, 0.4),
(13, 15, 5, 5, 2.5),
(13, 16, 3, 3, 1.5),
(13, 17, 2, 2, 0.6),
(13, 18, 2, 2, 0.6),
(13, 19, 3, 3, 1.2),
(13, 20, 5, 5, 2.5),
(13, 21, 1, 1, 0.5),
(14, 12, 4, 4, 2),
(14, 13, 1, 1, 0.2),
(14, 14, 1, 1, 0.2),
(14, 15, 4, 4, 2),
(14, 16, 3, 3, 1.5),
(14, 17, 1, 1, 0.3),
(14, 18, 3, 3, 0.9),
(14, 19, 4, 4, 1.6),
(14, 20, 5, 5, 2.5),
(14, 21, 1, 1, 0.5),
(15, 12, 3, 3, 1.5),
(15, 13, 1, 1, 0.2),
(15, 14, 1, 1, 0.2),
(15, 15, 2, 2, 1),
(15, 16, 5, 5, 2.5),
(15, 17, 3, 3, 0.9),
(15, 18, 3, 3, 0.9),
(15, 19, 4, 4, 1.6),
(15, 20, 2, 2, 1),
(15, 21, 5, 5, 2.5),
(16, 12, 2, 2, 1),
(16, 13, 2, 2, 0.4),
(16, 14, 1, 1, 0.2),
(16, 15, 5, 5, 2.5),
(16, 16, 2, 2, 1),
(16, 17, 2, 2, 0.6),
(16, 18, 2, 2, 0.6),
(16, 19, 3, 3, 1.2),
(16, 20, 5, 5, 2.5),
(16, 21, 2, 2, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `alternatif`
--
ALTER TABLE `alternatif`
 ADD PRIMARY KEY (`id_alternatif`);

--
-- Indexes for table `kriteria`
--
ALTER TABLE `kriteria`
 ADD PRIMARY KEY (`id_kriteria`);

--
-- Indexes for table `nilai`
--
ALTER TABLE `nilai`
 ADD PRIMARY KEY (`id_nilai`);

--
-- Indexes for table `pengguna`
--
ALTER TABLE `pengguna`
 ADD PRIMARY KEY (`id_pengguna`);

--
-- Indexes for table `rangking`
--
ALTER TABLE `rangking`
 ADD PRIMARY KEY (`id_alternatif`,`id_kriteria`), ADD KEY `id_kriteria` (`id_kriteria`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `alternatif`
--
ALTER TABLE `alternatif`
MODIFY `id_alternatif` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `kriteria`
--
ALTER TABLE `kriteria`
MODIFY `id_kriteria` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT for table `nilai`
--
ALTER TABLE `nilai`
MODIFY `id_nilai` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `pengguna`
--
ALTER TABLE `pengguna`
MODIFY `id_pengguna` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `rangking`
--
ALTER TABLE `rangking`
ADD CONSTRAINT `rangking_ibfk_1` FOREIGN KEY (`id_alternatif`) REFERENCES `alternatif` (`id_alternatif`),
ADD CONSTRAINT `rangking_ibfk_2` FOREIGN KEY (`id_kriteria`) REFERENCES `kriteria` (`id_kriteria`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
