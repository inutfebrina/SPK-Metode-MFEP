<?php
$host = "localhost";
$username = "root";
$password="";
$databasename = "spk_mfep";
$connection = mysql_connect($host,$username,$password)or die ("kesalahan koneksi....!!!");
mysql_select_db($databasename,$connection) or die ("Database Error");

?>